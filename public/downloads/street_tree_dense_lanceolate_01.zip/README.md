# Árvore urbana de copa densa 01

Asset 2D procedural original produzido com o A7 Forge 2D a partir de uma referência fotográfica própria.

Conteúdo:
- SOUTH, WEST, NORTH e EAST em PNG RGBA transparente;
- canvas 256x320;
- câmera CH_CAMERA_V1;
- tile de referência 128x64.

O preview técnico mostrado no site é apenas uma ficha de validação sobre grid sintético, não uma captura do runtime.
